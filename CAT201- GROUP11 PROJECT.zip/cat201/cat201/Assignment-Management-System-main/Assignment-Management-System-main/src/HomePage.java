import java.awt.*;
import javax.swing.*;

public class HomePage extends javax.swing.JFrame {

    public HomePage() {
        initComponents();
    }

    private void initComponents() {
        jPanel1 = new javax.swing.JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
        
                g.setColor(new Color(0, 0, 255)); // Light yellow color
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        

        jPanel1.setLayout(new BorderLayout());

        JPanel contentPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(30, 20, 20, 20);

        jLabel1 = new javax.swing.JLabel();
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 48));
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/welcome icon.png")));
        jLabel1.setText("Welcome");
        contentPanel.add(jLabel1, gbc);

        gbc.gridy++;
        jButtonStudentSignup = new javax.swing.JButton();
        jButtonStudentSignup.setFont(new java.awt.Font("Tahoma", 1, 18));
        jButtonStudentSignup.setForeground(new java.awt.Color(0, 118, 221));
        jButtonStudentSignup.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/login.png")));
        jButtonStudentSignup.setText("Sign Up");
        jButtonStudentSignup.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonStudentSignupMouseClicked(evt);
            }
        });
        contentPanel.add(jButtonStudentSignup, gbc);

        gbc.gridy++;
        jButtonStudentLogin = new javax.swing.JButton();
        jButtonStudentLogin.setFont(new java.awt.Font("Tahoma", 1, 18));
        jButtonStudentLogin.setForeground(new java.awt.Color(0, 118, 221));
        jButtonStudentLogin.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/login.png")));
        jButtonStudentLogin.setText("Log In");
        jButtonStudentLogin.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonStudentLoginMouseClicked(evt);
            }
        });
        contentPanel.add(jButtonStudentLogin, gbc);

        jPanel1.add(contentPanel, BorderLayout.CENTER);

        getContentPane().add(jPanel1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        pack();
    }

    private void jButtonStudentSignupMouseClicked(java.awt.event.MouseEvent evt) {
        setVisible(false);
        new StudentSignUp().setVisible(true);
    }

    private void jButtonStudentLoginMouseClicked(java.awt.event.MouseEvent evt) {
        setVisible(false);
        new StudentLogin().setVisible(true);
    }

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(() -> new HomePage().setVisible(true));
    }

    // Variables declaration
    private javax.swing.JButton jButtonStudentLogin;
    private javax.swing.JButton jButtonStudentSignup;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration
}

