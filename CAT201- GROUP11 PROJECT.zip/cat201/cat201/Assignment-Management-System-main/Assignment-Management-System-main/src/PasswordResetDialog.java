import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class PasswordResetDialog extends javax.swing.JDialog {

    private javax.swing.JButton jButtonReset;
    private javax.swing.JLabel jLabelEmailReset;
    private javax.swing.JTextField jTextFieldEmailReset;
    private javax.swing.JLabel jLabelNewPassword;
    private javax.swing.JPasswordField jPasswordFieldNewPassword;

    public PasswordResetDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    private void initComponents() {

        jLabelEmailReset = new javax.swing.JLabel();
        jTextFieldEmailReset = new javax.swing.JTextField();
        jLabelNewPassword = new javax.swing.JLabel();
        jPasswordFieldNewPassword = new javax.swing.JPasswordField();
        jButtonReset = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Password Reset");
        setResizable(false);

        jLabelEmailReset.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabelEmailReset.setText("Enter your email:");

        jTextFieldEmailReset.setFont(new java.awt.Font("Tahoma", 0, 18));

        jLabelNewPassword.setFont(new java.awt.Font("Tahoma", 1, 18));
        jLabelNewPassword.setText("Enter new password:");

        jPasswordFieldNewPassword.setFont(new java.awt.Font("Tahoma", 0, 18));

        jButtonReset.setFont(new java.awt.Font("Tahoma", 1, 18));
        jButtonReset.setText("Reset Password");
        jButtonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonResetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(34, 34, 34)
                                                .addComponent(jLabelEmailReset)
                                                .addGap(18, 18, 18)
                                                .addComponent(jTextFieldEmailReset, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(34, 34, 34)
                                                .addComponent(jLabelNewPassword)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jPasswordFieldNewPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(125, 125, 125)
                                                .addComponent(jButtonReset, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(31, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(34, 34, 34)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelEmailReset)
                                        .addComponent(jTextFieldEmailReset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabelNewPassword)
                                        .addComponent(jPasswordFieldNewPassword, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addComponent(jButtonReset, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(28, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void jButtonResetActionPerformed(java.awt.event.ActionEvent evt) {
        // Reset password logic
        String enteredEmail = jTextFieldEmailReset.getText();
        char[] newPasswordChars = jPasswordFieldNewPassword.getPassword();
        String newPassword = new String(newPasswordChars);
    
        // Validate entered email and password (add your own validation logic)
        if (enteredEmail.isEmpty() || newPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both email and new password.");
            return;
        }
    
        // Update the password in your data store (file or database)
        boolean passwordResetSuccessful = updatePassword(enteredEmail, newPassword);
    
        if (passwordResetSuccessful) {
            JOptionPane.showMessageDialog(this, "Password reset successful ! Your new password is: " + newPassword);
            dispose(); // Close the reset password dialog
        } else {
            JOptionPane.showMessageDialog(this, "Password reset failed. Please try again.");
        }
    }

    private boolean updatePassword(String email, String newPassword) {
        try {
            File inputFile = new File("studentinfo.txt");
            File tempFile = new File("temp_user_data.txt");
    
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));
    
            String currentLine;
            boolean emailFound = false;
    
            while ((currentLine = reader.readLine()) != null) {
                String[] parts = currentLine.split(",");
                String existingEmail = parts[2].trim();  // Assuming email is at index 2
    
                // Check if the current line contains the email to be updated
                if (existingEmail.equals(email)) {
                    // Update the password in the line
                    parts[3] = newPassword;  // Assuming password is at index 3
                    emailFound = true;
                }
    
                // Write the current line to the temporary file
                writer.write(String.join(",", parts) + System.lineSeparator());
            }
    
            // Close the readers and writers
            reader.close();
            writer.close();
    
            // Delete the original file
            if (!inputFile.delete()) {
                System.out.println("Error deleting the original file.");
                return false;
            }
    
            // Rename the temporary file to the original file
            if (!tempFile.renameTo(inputFile)) {
                System.out.println("Error renaming the temporary file.");
                return false;
            }
    
            if (!emailFound) {
                // Email not found, show an error message
                JOptionPane.showMessageDialog(this, "Email not found. Password update failed.");
                return false; // Password update failed
            }
    
            return true;  // Password update successful
        } catch (IOException e) {
            e.printStackTrace();
            return false; // Password update failed
        }
    }

    public static void main(String[] args) {
        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PasswordResetDialog dialog = new PasswordResetDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
}
